from flask import Flask, render_template, request, redirect, session
from Sql import get_database_connection

app = Flask(__name__)
app.secret_key = "secret_9116946977"

@app.route('/')
def index():
    if 'username' in session:
        return render_template('index.html')
    else:
        return redirect('/login')
    # You may want to pass some data to the template

@app.route('/login', methods=['GET','POST'])
def login():
    if  request.method == 'POST': 
        email = request.form["email"]
        password = request.form["password"]
        query = "SELECT email FROM user_table WHERE email = %s AND password = %s"
        try:
            mydb = get_database_connection()
            mycursor = mydb.cursor()
            mycursor.execute(query, (email, password))
            user = mycursor.fetchone()
            session['username'] = user
            print(user)
            if user:
                # Authentication successful, redirect or return success response
                return redirect('/')
            else:
                # Authentication failed, redirect or return error response
                return render_template('login.html')
        except Exception as e:
            # Handle database errors
            return str(e)
    else :
        return render_template('login.html')
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        full_name = request.form.get('name')
        email = request.form.get('email')
        gender = request.form.get('gender')
        age = request.form.get('age')
        password = request.form.get('password')
        try:
            mydb = get_database_connection()
            mycursor = mydb.cursor()
            query = "INSERT INTO user_table (full_name, email, gender, Age, PASSWORD) VALUES (%s, %s, %s, %s, %s)"
            mycursor.execute(query, (full_name, email, gender, age, password))
            mydb.commit()
            # Registration successful, redirect or return success response
            return "Registration successful"
        except Exception as e:
            # Handle database errors
            return str(e)
    else:
        # Handle GET request for signup page
        return render_template('signup.html')
    
@app.route("/logout", methods=['POST'])
def logout() :
    session.pop('username', None)
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
