import mysql.connector as sql # type: ignore

def get_database_connection():
    return sql.connect(
        host="localhost",
        user="root",
        password="123456",
        database="database_ml"
    )